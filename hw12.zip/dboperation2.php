<form action="adminpage.php" method ="get"> 
	
	
	<input type='submit' name = 'adminpage'  value='return to Admin Page' >
	
</form>

<?php
include 'include/dbconn1.php';



?>